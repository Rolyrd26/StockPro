STOCKPRO ANDROID — INTERFAZ MEJORADA

Esta versión actualiza el diseño visual adaptable a teléfonos y pantallas grandes. Conserva las funciones existentes de productos, ventas, movimientos, reportes y ajustes. La moneda predeterminada es el peso cubano (CUP).

NOTA: los datos de la aplicación se guardan localmente en el almacenamiento del navegador/WebView de este dispositivo. Haz una exportación/copia antes de borrar datos de la aplicación o desinstalarla.

STOCKPRO PARA ANDROID — COMPILACIÓN DESDE EL TELÉFONO

El proyecto incluye una aplicación Android y un flujo de GitHub Actions para crear el APK en la nube. La moneda predeterminada es CUP.

PASOS DESDE ANDROID
1. Descarga StockProAndroid.zip en tu teléfono.
2. Abre github.com en Chrome e inicia sesión.
3. Crea un repositorio nuevo (por ejemplo, StockProAPK). Puedes dejarlo privado.
4. Entra al repositorio y usa Add file > Upload files para subir el archivo StockProAndroid.zip. Confirma el commit.
5. En el repositorio, pulsa Add file > Create new file.
6. En el nombre del archivo escribe exactamente: .github/workflows/build-apk.yml
7. Abre el archivo build-apk.yml dentro de este ZIP (con un administrador de archivos que pueda abrir ZIP), copia todo su contenido y pégalo en el editor de GitHub. Confirma el commit.
8. En el repositorio abre la pestaña Actions. Selecciona “Build StockPro APK” y pulsa “Run workflow” si aparece. También se inicia automáticamente al subir el ZIP o el archivo del flujo.
9. Espera a que la ejecución termine en verde. Entra en la ejecución y busca Artifacts; descarga “StockPro-APK”.
10. Descomprime el artefacto descargado. Dentro estará app-debug.apk. Tócalo para instalarlo y acepta la instalación desde esa fuente si Android lo solicita.

NOTAS
- No subas contraseñas, tokens ni datos personales al repositorio.
- Si quieres mantener el código privado, elige repositorio privado.
- Este APK es una compilación de prueba (debug), no una versión firmada para publicar en Play Store.
- La app guarda datos localmente en el almacenamiento de la aplicación. Haz copias de seguridad antes de borrar datos o desinstalar.
- La descarga/exportación de archivos desde el interior de la app puede necesitar ajustes nativos; prueba esa función antes de depender de ella para copias de seguridad.
